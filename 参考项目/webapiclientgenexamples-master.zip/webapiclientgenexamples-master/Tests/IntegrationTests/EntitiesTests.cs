﻿using Xunit;
using DemoWebApi.Controllers.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Just.Tests
{
    public class EntitiesTests
    {
        [Fact()]
        public void EntitiesTest()
        {
            Assert.True(false, "This test needs an implementation");
        }

        [Fact()]
        public void GetPersonAsyncTest()
        {
            Assert.True(false, "This test needs an implementation");
        }

        [Fact()]
        public void GetPersonTest()
        {
            Assert.True(false, "This test needs an implementation");
        }

        [Fact()]
        public void CreatePersonAsyncTest()
        {
            Assert.True(false, "This test needs an implementation");
        }

        [Fact()]
        public void CreatePersonTest()
        {
            Assert.True(false, "This test needs an implementation");
        }

        [Fact()]
        public void UpdatePersonAsyncTest()
        {
            Assert.True(false, "This test needs an implementation");
        }

        [Fact()]
        public void UpdatePersonTest()
        {
            Assert.True(false, "This test needs an implementation");
        }

        [Fact()]
        public void DeleteAsyncTest()
        {
            Assert.True(false, "This test needs an implementation");
        }

        [Fact()]
        public void DeleteTest()
        {
            Assert.True(false, "This test needs an implementation");
        }
    }
}