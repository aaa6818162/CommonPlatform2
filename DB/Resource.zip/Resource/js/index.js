 $(function(){
 /*     /!* 轮播图 *!/
    var mySwiper = new Swiper('.swiper-container', {
      direction: 'horizontal',
      loop: true,
      autoplay: true,
      speed: 1000,
      effect: 'fade',
      // 分页器
      pagination: {
        el: '.swiper-pagination',
      }

    });*/

















 });
